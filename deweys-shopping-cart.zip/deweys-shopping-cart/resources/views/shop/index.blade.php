@extends('layouts.master')

@section('title')
Deweys Shopping Cart
@endsection

@section('content')
<div class="row">
<div class="col-sm-6 col-md-4">
<div class="card" style="width: 18rem;">
  <img src="https://asset1.cxnmarksandspencer.com/is/image/mands/Conde-de-Albeta---Case-of-6-1/SD_FD_F23A_00109048_NC_X_EC_0?$PDP_MAIN_CAR_LG$" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Conde de Albeta</h5>
    <p class="card-text">An aromatic and fruit-driven dry white with flavours of white peaches, lemons and almonds. Serve with smoked salmon, pea risotto or as an aperitif.</p>
    <div class="price" >£12</div>
    <br>
    <a href="#" class="btn btn-primary">Add to Cart</a>
  </div>
</div>
</div>

<div class="col-sm-6 col-md-4">
<div class="card" style="width: 18rem;">
  <img src="https://asset1.cxnmarksandspencer.com/is/image/mands/Silver-Frond-Sauvignon-Blanc---Case-of-6-1/HT_FD_F23A_00051774_NC_X_EC_0?$PDP_MAIN_CAR_LG$" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Silver Frond Sauvignon Blanc</h5>
    <p class="card-text">Enjoy nicely chilled as a mouthwatering aperitif or with fish and chips, Thai fishcakes or creamy pasta with asparagus.</p>
    <div class="price" >£15</div>
    <br>
    <a href="#" class="btn btn-primary">Add to Cart</a>
  </div>
</div>
</div>

<div class="col-sm-6 col-md-4">
<div class="card" style="width: 18rem;">
  <img src="https://asset1.cxnmarksandspencer.com/is/image/mands/Les-Ruettes-Sancerre---Case-of-6-1/SD_FD_F23A_00471299_NC_X_EC_0?$PDP_MAIN_CAR_LG$" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Les Ruettes Sancerre</h5>
    <p class="card-text">Serve lightly chilled as a mouth-watering aperitif or as a palate-cleansing foil to dishes such as baked salmon or a goat’s cheese salad.</p>
    <div class="price" >£19</div>
    <br>
    <a href="#" class="btn btn-primary">Add to Cart</a>
  </div>
</div>
</div>

</div>

<div class="row">
<div class="col-sm-6 col-md-4">
<div class="card" style="width: 18rem;">
  <img src="https://asset1.cxnmarksandspencer.com/is/image/mands/Gold-Label-Merlot---Case-of-6-1/HT_FD_F23A_00592345_NC_X_EC_0?$PDP_MAIN_CAR_LG$" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Gold Label Merlot</h5>
    <p class="card-text">A fruity, medium bodied French red with plum and strawberry flavours. Beautifully supple and fruity, this wine is ideal to serve on its own or paired with succulent slow-cooked meats.

</p>
    <div class="price" >£12</div>
    <br>
    <a href="#" class="btn btn-primary">Add to Cart</a>
  </div>
</div>
</div>

<div class="col-sm-6 col-md-4">
<div class="card" style="width: 18rem;">
  <img src="https://asset1.cxnmarksandspencer.com/is/image/mands/Torre-Oria-Reserva---Case-of-6-1/SD_FD_F23A_00977708_NC_X_EC_0?$PDP_MAIN_CAR_LG$" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">
Torre Oria Reserva</h5>
    <p class="card-text">A medium bodied Spanish red with ripe strawberry notes, dried fruit and vanilla and coconut notes. An ideal accompaniment alongside roast lamb or beef.</p>
    <div class="price" >£16</div>
    <br>
    <a href="#" class="btn btn-primary">Add to Cart</a>
  </div>
</div>
</div>

<div class="col-sm-6 col-md-4">
<div class="card" style="width: 18rem;">
  <img src="https://asset1.cxnmarksandspencer.com/is/image/mands/SD_FD_F23A_00577670_NC_X_EC_0?wid=240&qlt=40&fmt=pjpeg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Amarone della Valpolicella Villalta</h5>
    <p class="card-text">A voluptuously smooth, full-bodied Italian red with dried cherry and raisin aromas. Enjoy this wine over the next five years with slow-cooked game dishes and fine Parmesan cheese.</p>
    <div class="price" >£30</div>
    <br>
    <a href="#" class="btn btn-primary">Add to Cart</a>
  </div>
</div>
</div>

</div>

@endsection
