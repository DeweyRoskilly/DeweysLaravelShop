<?php

use Illuminate\Database\Seeder;

class ProductTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $product = new \App\Product([
            'imagePath' => 'https://asset1.cxnmarksandspencer.com/is/image/mands/Conde-de-Albeta---Case-of-6-1/SD_FD_F23A_00109048_NC_X_EC_0?$PDP_MAIN_CAR_LG$',
            'title' => 'Conde de Albeta',
            'description' => 'An aromatic and fruit-driven dry white with flavours of white peaches, lemons and almonds. Serve with smoked salmon, pea risotto or as an aperitif.',
            'price' => '12'
        ]);
        $product->save();

        $product = new \App\Product([
            'imagePath' => 'https://asset1.cxnmarksandspencer.com/is/image/mands/Silver-Frond-Sauvignon-Blanc---Case-of-6-1/HT_FD_F23A_00051774_NC_X_EC_0?$PDP_MAIN_CAR_LG$',
            'title' => 'Silver Frond Sauvignon Blanc',
            'description' => 'Enjoy nicely chilled as a mouthwatering aperitif or with fish and chips, Thai fishcakes or creamy pasta with asparagus.',
            'price' => '15'
        ]);
        $product->save();

        $product = new \App\Product([
            'imagePath' => 'https://asset1.cxnmarksandspencer.com/is/image/mands/Les-Ruettes-Sancerre---Case-of-6-1/SD_FD_F23A_00471299_NC_X_EC_0?$PDP_MAIN_CAR_LG$',
            'title' => 'Les Ruettes Sancerre',
            'description' => 'Serve lightly chilled as a mouth-watering aperitif or as a palate-cleansing foil to dishes such as baked salmon or a goat’s cheese salad.',
            'price' => '19'
        ]);
        $product->save();        

        $product = new \App\Product([
            'imagePath' => 'https://asset1.cxnmarksandspencer.com/is/image/mands/Gold-Label-Merlot---Case-of-6-1/HT_FD_F23A_00592345_NC_X_EC_0?$PDP_MAIN_CAR_LG$',
            'title' => 'Gold Label Merlote',
            'description' => 'A fruity, medium bodied French red with plum and strawberry flavours. Beautifully supple and fruity, this wine is ideal to serve on its own or paired with succulent slow-cooked meats.',
            'price' => '12'
        ]);
        $product->save();        
        $product = new \App\Product([
            'imagePath' => 'https://asset1.cxnmarksandspencer.com/is/image/mands/Torre-Oria-Reserva---Case-of-6-1/SD_FD_F23A_00977708_NC_X_EC_0?$PDP_MAIN_CAR_LG$',
            'title' => 'Torre Oria Reserva',
            'description' => 'A medium bodied Spanish red with ripe strawberry notes, dried fruit and vanilla and coconut notes. An ideal accompaniment alongside roast lamb or beef.',
            'price' => '16'
        ]);
        $product->save();    
        $product = new \App\Product([
            'imagePath' => 'https://asset1.cxnmarksandspencer.com/is/image/mands/SD_FD_F23A_00577670_NC_X_EC_0?wid=240&qlt=40&fmt=pjpeg',
            'title' => 'Amarone della Valpolicella Villalta',
            'description' => 'A voluptuously smooth, full-bodied Italian red with dried cherry and raisin aromas. Enjoy this wine over the next five years with slow-cooked game dishes and fine Parmesan cheese.',
            'price' => '16'
        ]);
        $product->save();    
    
    
    }
}
